"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEstates = void 0;
var getEstates = function (request) {
    return { statusCode: 200, body: request.body };
};
exports.getEstates = getEstates;
