"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCountries = void 0;
var getCountries = function (request) {
    return { statusCode: 200, body: request.body };
};
exports.getCountries = getCountries;
